# BLOCK DIAGRAM
![Rain-Sensing-Automatic-Car-Wiper-block](https://user-images.githubusercontent.com/94339884/155120111-2813d9d2-c93e-42fd-a097-ad36c676f6dd.png)


# FLOW CHART
#2 ![flowchart (1)](https://user-images.githubusercontent.com/94339884/155848819-7b8c62e0-65d8-4ca0-aedf-3b362ca329c3.png)


# behaviour diagram 
#1 ![bhehavior diagram](https://user-images.githubusercontent.com/94339884/155848842-c2d4ce15-0d94-4586-87ab-92e33cad6c56.png)