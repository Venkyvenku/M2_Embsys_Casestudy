# code file
> - rain_car_wiper_arduino.ino is ardino code file
> - carwiper.h is the header file for code
> - rain_car_wiper_arduino.ino.elf is the elf file
> - rain_car_wiper_arduino.ino.hex is the hex file.