# circuit output
![Screenshot (271)](https://user-images.githubusercontent.com/94339884/157226359-89ce3245-102a-44f6-b463-9f8799f5617b.png)
> - the circuit discription is given inside itself
> - the output video 
> https://user-images.githubusercontent.com/94339884/157227862-f1cf3824-0c8b-448b-acb1-127796a5a8aa.mp4


