# rain decting car wiper
## introduction
this car wiper can detect the rain and start cleaning the wind screen so that the water dont make the view unclear for the driver
## requirments
> CLEAN WIND SHEILD
- Detect the rain
- Clean the wind shield according to req
> design
- uses a rain sensor 
- uses a micro controller (eg atmega 328)
- uses an actuator(servo motor)
# BLOCK DIAGRAM

![blockdiagram](https://github.com/chittiravi10/M2_EMBSYS/issues/1#issue-1146769089)
![blockdiagram]()

# applications
- can clean the windows automaticaly
- the concept can be used in many other ways 
- it is a energy efficient and resource saving according to the use(like using in irrigation system and water saving)

# disadvantages 
- easily hackable
- - when we pour water on the sensor it will think it as rain and starts wiping (resource wastage)


#
- the disadvantages can be reduced when the version is improved
