# M2_EMBSYS_case study
EMBEDED SYSTEM PROJECT
>>"this case study has a little resembelence from net  because i tried to get some info for further study "
- i donot support any kind of palagrism 
- pardon me if there is any spelling mistake
- also this was a little same from the projet i made my collage